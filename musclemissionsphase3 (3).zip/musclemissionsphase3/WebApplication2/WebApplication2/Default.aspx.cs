﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
	public partial class WebForm1 : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
            ImageButton1.Visible = false;
            ImageButton7.Visible = false;
            ImageButton5.Visible = false;
            ImageButton3.Visible = false;
            ImageButton4.Visible = false;
            ImageButton13.Visible = false;
            Panel6.Visible = false;
            Panel11.Visible = false;
            Panel12.Visible = false;
		}

		protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
		{
            ImageButton1.Visible = true;
            ImageButton7.Visible = true;
            ImageButton5.Visible = true;
            ImageButton3.Visible = true;
            ImageButton4.Visible = true;
            ImageButton13.Visible = true;
            ImageButton6.Visible = false;
        }
        protected void ImageButton13_Click(object sender, ImageClickEventArgs e)
        {
           /* ImageButton1.Visible = false;
            ImageButton7.Visible = false;
            ImageButton5.Visible = false;
            ImageButton3.Visible = false;
            ImageButton4.Visible = false;
            ImageButton13.Visible = false;*/
            ImageButton6.Visible = true;
        }
        protected void ImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton1.Visible = false;
            ImageButton7.Visible = false;
            ImageButton5.Visible = false;
            ImageButton3.Visible = false;
            ImageButton4.Visible = false;
            ImageButton13.Visible = false;
            ImageButton6.Visible = true;
        }
        protected void ImageButton11_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton1.Visible = false;
            ImageButton7.Visible = false;
            ImageButton5.Visible = false;
            ImageButton3.Visible = false;
            ImageButton4.Visible = false;
            ImageButton13.Visible = false;
            ImageButton6.Visible = true;
        }
        protected void ImageButton12_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton1.Visible = false;
            ImageButton7.Visible = false;
            ImageButton5.Visible = false;
            ImageButton3.Visible = false;
            ImageButton4.Visible = false;
            ImageButton13.Visible = false;
            ImageButton6.Visible = true;
            Panel6.Visible = true;
        }
        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            Server.Transfer("WebForm2.aspx");
        }
        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            Server.Transfer("WebForm3.aspx");
        }
        protected void ImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("WebForm5.aspx");
        }
        protected void button1_click(object sender, EventArgs e)
        {
            Panel6.Visible = true;
        }
        protected void button2_click(object sender, EventArgs e)
        {
            Panel11.Visible = true;
        }
        protected void button3_click(object sender, EventArgs e)
        {
            Panel12.Visible = true;
        }
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton1.Visible = false;
            ImageButton7.Visible = false;
            ImageButton5.Visible = false;
            ImageButton3.Visible = false;
            ImageButton4.Visible = false;
            ImageButton13.Visible = false;
            ImageButton6.Visible = true;
        }
        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("WebForm4.aspx");
        }
    }
}