﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Panel10.Visible = false;
            Panel11.Visible = false;
            Panel12.Visible = false;
            Panel13.Visible = false;
            ImageButton1.Visible = false;
            ImageButton7.Visible = false;
        }
        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("WebForm2.aspx");
        }
        protected void ImageButton14_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton13.Visible=true;
        }
        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            Server.Transfer("WebForm3.aspx");
        }
        protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton1.Visible = true;
        }
        protected void ImageButton13_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton1.Visible = true;
            ImageButton7.Visible = true;
        }
        protected void ImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton1.Visible = false;
        }
        protected void ImageButton11_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton1.Visible = false;
        }
        protected void ImageButton12_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton1.Visible = false;
          
        }
        protected void ImageButton7_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("WebForm5.aspx");
        }
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Default.aspx");      
        }
        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("WebForm4.aspx");
        }
        protected void ImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("WebForm4.aspx");
        }

    }
}